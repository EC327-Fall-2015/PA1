#include <iostream>
#include <stdio.h>      
#include <stdlib.h>
#include <time.h>
using namespace std;


int main()
{
	int answer, guess1, guess2;
	srand (time(NULL));
	answer = rand() % 1000; // set cap at 1000 so the random number isn't too large
	cout << "Enter your first guess: ";
	cin >> guess1;
	cout << "Enter your next guess: ";
	cin >> guess2;
	while (guess1 != answer && guess2 != answer) // to make sure neither guess was correct already
	{
		if (abs(answer - guess1) < abs(answer - guess2)) // result should be colder if guess2 has a greater distance from the answer
		{
			cout << "Colder" << endl;
			cout << "Enter your next guess: ";
			guess1 = guess2; // to make sure we always compare to the previous guess
			cin >> guess2;
		}
		else if (abs(answer - guess1) > abs(answer - guess2)) // result should be warmer if guess2 has a smaller distance from the answer
		{
			cout << "Warmer" << endl;
			cout << "Enter your next guess: ";
			guess1 = guess2; // to make sure we always compare to the previous guess
			cin >> guess2;
		}
		else if (abs(answer - guess1) == abs(answer - guess2)) // result should be no change if guess2 has an equal distance from the answer
		{
			cout << "No change" << endl;
			cout << "Enter your next guess: ";
			guess1 = guess2; // to make sure we always compare to the previous guess
			cin >> guess2;
		}
	}
	cout << "Correct! The number was " << answer << "!" << endl;

	return 0;
}