#include <iostream>
#include "math.h"
using namespace std;

// function for calculating area
double herons(double side1, double side2, double side3)
{
	double s = (side1 + side2 + side3)/2;
	double temp = s*(s-side1)*(s-side2)*(s-side3);
	double area = sqrt(temp);
	
	return area;
}
// function for calculating perimeter
double perimeter(double s1, double s2, double s3)
{
	double perim = s1 + s2 + s3;

	return perim;
}

int main()
{
	cout << "Enter the dimensions of the triangle:" << endl;
	cout << "Side-1: ";
	double a,b,c;
	cin >> a;
	cout << "Side-2: ";
	cin >> b;
	cout << "Side-3: ";
	cin >> c;
	if(a+b>c && a+c>b && b+c>a) // making sure sides create a triangle before calculating area/perimeter
	{
		cout << "This triangle's area is " << herons(a,b,c) << " square-units and its perimeter is " << perimeter(a,b,c) << " units." << endl;
	}
	else // if sides don't create triangle, end program
		cout << "Dimensions " << a << ", " << b << ", " << c << " do not form a triangle." << endl;

	return 0;
}