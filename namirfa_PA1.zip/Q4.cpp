#include <iostream>
#include <sstream>
#include "stdio.h"
#include "stdlib.h"
using namespace std;

// function to convert to capital
char convertcapital(char a)
{
	int b = a - 32;
	char x = b;
	return x;	
}
// function to convert to lowercase
char convertlowercase(char a)
{
	int b = a + 32;
	char x = b;
	return x;
}
int main()
{
	int offset;
	char letter;
	char new_letter;
	int ascii_letter1, ascii_letter2;
	cout << "Enter character: ";
	cin >> letter;
	cout << "Offset (enter 0 to convert case): ";
	cin >> offset ;
	ascii_letter1 = letter;

	while ((ascii_letter1 + offset) > 127) // to make sure the offset puts the ASCII number out of range
		{	
			cout << "ASCII number is out of range. Please re-enter offset: ";
			cin >> offset;
		}
	// to convert letters, or keep input the same
	if (offset == 0)
	{
		if (ascii_letter1 > 96 && ascii_letter1 < 123)
		{	
			cout << "New character: " << convertcapital(ascii_letter1) << endl;
		}

		else if (ascii_letter1 > 64 && ascii_letter1 < 91)
		{
			cout << "New character: " << convertlowercase(ascii_letter1) << endl;
		}

		else 
		{
			cout << "New character: " << letter << endl;
		}
	}
	// to offset the letter, number, etc...
	else
	{
		ascii_letter2 = ascii_letter1 + offset;
		new_letter = ascii_letter2;
		cout << "New character: " << new_letter << endl;
	}

return 0;

}

