#include <iostream>
using namespace std;

int main()
{
	int number1, number2;
	string hexnumber1, hexnumber2;
	int hammingdistance = 0;
	cout << "Enter two positive integers" << endl;
	cin >> number1;
	cin >> number2;
	hexnumber1 = hex(number1);
	hexnumber2 = hex(number2);
	for (int i = 0, i < hexnumber1.length(), i += 1)
	{
		if (hexnumber1[i] == hexnumber2[i])
		{
			hammingdistance += 0;
		}
		else
		{
			hammingdistance += 1;
		}
	}

	cout << "Hamming distance between " << number1 << "and " << number2 << "when numbers are in hex format is: " << hammingdistance << endl;

	return 0
}