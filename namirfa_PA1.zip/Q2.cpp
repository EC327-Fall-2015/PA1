#include <iostream>
#include "math.h"
using namespace std;
// function to convert celsius to fahrenheit
double CelsiustoF(double celsius)
{
	
	double fahrenheit = (celsius * 1.8) + 32;
	cout << celsius << " Celsius is " << fahrenheit << " Fahrenheit" << endl;

	return 0;
}
// function to convert celsius to kelvin
double CelsiustoK(double celsius)
{
	
	double kelvin = celsius + 273.15;
	cout << celsius << " Celsius is " << kelvin << " Kelvin" << endl;

	return 0;
}
// function to convert fahrenheit to celsius
double FahrenheittoC(double fahrenheit)
{
	
	double celsius = (fahrenheit - 32) / 1.8;
	cout << fahrenheit << " Fahrenheit is " << celsius << " Celsius" << endl;

	return 0;
}
// function to convert fahrenheit to kelvin
double FahrenheittoK(double fahrenheit)
{

	double kelvin = (fahrenheit + 459.67) * (5/9);
	cout << fahrenheit << " Fahrenheit is " << kelvin << " Kelvin" << endl;

	return 0; 
}
// funtion to convert kelvin to celsius
double KelvintoC(double kelvin)
{
	
	double celsius = kelvin - 273.15;
	cout << kelvin << " Kelvin is " << celsius << " Celsius " << endl;

	return 0;
}
// function to convert kelvin to fahrenheit
double KelvintoF(double kelvin)
{
	
	double fahrenheit = (kelvin * 1.8) - 459.67; 
	cout << kelvin << " Kelvin is " << fahrenheit << " Fahrenheit " << endl;

	return 0;
}

int main()
{
	cout << "Celsius to Fahrenheit (enter 0)" << endl;
	cout << "Celsius to Kelvin (enter 1)" << endl;
	cout << "Fahrenheit to Celsius (enter 2)" << endl;
	cout << "Fahrenheit to Kelvin (enter 3)" << endl;
	cout << "Kelvin to Celsius (enter 4)" << endl;
	cout << "Kelvin to Fahrenheit (enter 5)" << endl;
	cout << "Conversion type: ";
	double a;
	double celsius,fahrenheit,kelvin;
	cin >> a;

	while (a < 0 || a > 5) // making sure the user inputs a valid number
	{
		cout << "You have entered an incorrect value, please enter another value : ";
		cin >> a;
	}
	// matches function to the number the user inputs
	if (a == 0) 
	{
		cout << "Enter the amount in Celsius: ";
		cin >> celsius;
		CelsiustoF(celsius);
	}

	else if (a == 1)
	{
		cout << "Enter the amount in Celsius: ";
		cin >> celsius;
		CelsiustoK(celsius);
	}

	else if (a == 2)
	{
		cout << "Enter the amount in Fahrenheit: ";
		cin >> fahrenheit;
		FahrenheittoC(fahrenheit);
	}

	else if (a == 3)
	{
		cout << "Enter the amount in Fahrenheit: ";
		cin >> fahrenheit;
		FahrenheittoK(fahrenheit);
	}

	else if (a == 4)
	{
		cout << "Enter the amount in Kelvin: ";
		cin >> kelvin;
		KelvintoC(kelvin);
	}

	else
	{
		cout << "Enter the amount in Kelvin: ";
		cin >> kelvin;
		KelvintoF(kelvin);
	}
	
	return 0;
}
