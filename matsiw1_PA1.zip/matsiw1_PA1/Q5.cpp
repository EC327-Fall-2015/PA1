// Warmer or Colder?

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cmath>

using namespace std;


int main()
{  
	 // Initialize random value
	int rando = 0;

	srand(time(0));

	rando = rand() % 500 + 1;
	
	// Display messages and gather inputs 
	cout << "Enter your first guess: ";
	
	int beforeGuess = 0;

	cin >> beforeGuess;
	
	int nextGuess = 0;

	cout << "Enter your next guess: ";

	cin >> nextGuess;

	// Output message depending on absolute value distance from random value compared with last guess
	while (nextGuess != rando)
	{
		if (abs(rando - nextGuess) > abs(rando - beforeGuess))
		{
			cout << "Colder" << endl;
		}
		else if (abs(rando - nextGuess) < abs(rando - beforeGuess))
		{
			cout << "Warmer" << endl;
		}
		else if (abs(rando - nextGuess) == abs(rando - beforeGuess))
		{
			cout << "No change" << endl;
		}
		
		// Set previous guess and ask for new guess
		beforeGuess = nextGuess;
		cout << "Enter your next guess: ";
		cin >> nextGuess;
	}

	cout << "Correct! The number was " << rando << "!" << endl;	

	return 0;
}
