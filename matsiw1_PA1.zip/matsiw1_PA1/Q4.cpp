// Letter Conversion

#include <iostream>

using namespace std;

int main()
{
	//Display messages and gather inputs
	cout << "Enter character: ";

	char userIn;

	cin >> userIn;

	cout << "Offset (enter 0 to convert case): ";

	int moveTo = 0;

	cin >> moveTo;

	// If offset is too big, report error
	if (moveTo + static_cast<int>(userIn) > 127) 
		{
		cout << "Error. Out of range." << endl;
		return 0;
		}

	int tempValue = 0;

	// If offset is 0,  check if letter, then change case
	if (moveTo == 0)   
	{	
		if (static_cast<int>(userIn) > 96 && static_cast<int>(userIn) < 123)   
		{
			tempValue = static_cast<int>(userIn) - 32;
		 	userIn = static_cast<char>(tempValue);
		}
			else if (static_cast<int>(userIn) < 91 && static_cast<int>(userIn) > 64)
		{
			tempValue = static_cast<int>(userIn) + 32;
			userIn = static_cast<char>(tempValue);
		}
	}

	else
	{
		// Add offset to character
		tempValue = static_cast<int>(userIn) + moveTo;
		userIn = static_cast<char>(tempValue);
	}
	
	cout << "New character: " << userIn << endl;


	return 0;
}
