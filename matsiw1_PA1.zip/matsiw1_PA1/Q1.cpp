// Perimeter and area of triangles
#include <iostream>
#include <cmath>

using namespace std;

// Determine whether the dimensions make a triangle
int triangleDimensions(double one, double two, double three)
{  
	// If two sides are greater than the third side, it makes a triangle
	if (one + two > three)      
	{
		if (one + three > two)
		{
			if (two + three > one)
			{
				return 1;
			}
			else
			{
				return 2;
			}
		}  
		else
		{ 
			return 2;
		}
	}
	else
	{
		return 2;
	}
	return 0; 
}

// Calculate the area and perimeter if triangle.  
int calculateAreaAndPerimeter(int checkIfTriangle, double& area, double& perimeter, double sideOne, double sideTwo, double sideThree)
{
	// Use Heron's formula for calculating the area, then calculate the perimeter
	if (checkIfTriangle == 1)             
	{
		double average =(sideOne + sideTwo + sideThree) / 2;
  
		area = sqrt(average*(average - sideOne)*(average - sideTwo)*(average - sideThree));

		perimeter = sideOne + sideTwo + sideThree;

		return 1; 
	}
	else
	{
		return 2;
	}

	return 0;
}

int main ()
{
	// Display messages and user inputs
	cout << "Enter the dimensions of the triangle:" << endl;
 
	cout << "Side-1: ";

 	double sideOne = 0;

 	cin >> sideOne;

 	cout << "Side-2: ";

 	double sideTwo = 0;

 	cin >> sideTwo;

 	cout << "Side-3: ";

 	double sideThree = 0;

 	cin >> sideThree;

	// Check if dimensions make a triangle
 	int answer =  triangleDimensions(sideOne, sideTwo, sideThree); 

 	double area = 0;
 	double perimeter = 0;

	// Calculate the area and perimeter
 	int message = calculateAreaAndPerimeter(answer, area, perimeter, sideOne, sideTwo, sideThree);       

	// Display message depending on if triangle is formed
 	if (message == 2)			 
 	  {
 	   cout << "Dimensions " << sideOne << ", " << sideTwo << ", " << sideThree << " do not form a triangle." << endl;
 	  }
 	else
 	  {
 	   cout << "This triangle's area is " << area << " square-units, and its perimeter is " << perimeter << " units." << endl;
 	  }

 	return 0;
}



