// Hamming Distance

#include <iostream>

using namespace std;

int main()
{
	//Display messages and gather user inputs
	cout << "Enter two positive integers:" << endl;   
	
	long numOne = 0;
	long numTwo = 0;

	cin >> numOne;
	cin >> numTwo;

	long tempOne = numOne;
	long tempTwo = numTwo;
	
	int oneStr = 0;
	int twoStr = 0;
	int count = 0;
	
	// Check number by number whether remainders (hex values) are the same
	while (numOne > 0 && numTwo > 0)            
	{
	 	oneStr = numOne % 16;
		twoStr = numTwo % 16;
		if (oneStr != twoStr)
		{
			// Increment count if different
			count++;         			
		}
		numOne /= 16;
		numTwo /= 16;
	}
	
	cout << "Hamming distance between " << tempOne << " and " << tempTwo << " when numbers are in hex format is: " << count << endl;
	
	return 0;
}
