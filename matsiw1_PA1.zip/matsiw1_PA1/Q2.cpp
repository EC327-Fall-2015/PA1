// Converting Units

#include <iostream>
#include <iomanip>

using namespace std;

// Convert one unit to a different unit or return an error
int calculateConversion(double& userCode, double& userValue)    
{	
	// Celsius to Fahrenheit
    if (userCode == 0)          
    {
		if ((userValue / 1) == userValue)
		{
			userValue = ( userValue * (1.8) ) + 32;
		}
		else
		{
			userCode = 6;
		}
    }

	// Celsius to Kelvin
	else if (userCode == 1)        
	{
		if ((userValue / 1) == userValue)
		{
			userValue = userValue + 273.150;
		}
		else 
		{
			userCode = 6;
		}
    }

	// Fahrenheit to Celsius
	else if (userCode == 2)       
	{
		if ((userValue / 1) == userValue)
		{
			userValue = ( userValue - 32 ) / (1.8);
		}
		else
		{
        	userCode = 6;
		}
    }
	
	// Fahrenheit to Kelvin
	else if (userCode == 3)        
	{
		if ((userValue / 1) == userValue)
		{
			userValue = ( userValue - 32 ) / 1.8 + 273.15;
		}
		else
		{
        	userCode = 6;
	    }
    }
	
	// Kelvin to Celsius
	else if (userCode == 4)         
	{
		if ((userValue / 1) == userValue)
		{
			userValue = userValue - 273.150;
		}
		else
		{
			userCode = 6;
	    }
    }
   
	// Kelvin to Fahrentheit
	else if (userCode == 5)    
	{
		if ((userValue / 1) == userValue)
		{
			userValue = ( userValue - 273.15) * 1.8 + 32;
		}
		else
		{
			userCode = 6;
		}
    }
	
	// Tell the user code is incorrect
	else                            
	{
		userCode = 6;
	}

	return 0;
}


int main()
{
	// Display messages and gather inputs
	cout << "Celsius to Fahrenheit (enter 0)" << endl;         

	cout << "Celsius to Kelvin (enter 1)" << endl;

 	cout << "Fahrenheit to Celsius (enter 2)" << endl;

 	cout << "Fahrenheit to Kelvin (enter 3)" << endl;

 	cout << "Kelvin to Celsius (enter 4)" << endl;

 	cout << "Kelvin to Fahrenheit (enter 5)" << endl;
 	
 	cout << "Conversion type: ";
 	
 	double userCode = 0;

 	double userValue = 0;

 	double originalValue = 0;

 	cin >> userCode;

 	calculateConversion(userCode, userValue);
	
	// Display error if userCode is something other than 0 or 5
	while (userCode == 6)                                 
 	{
 		cout << "Wrong input, try again: ";
 	   
		cin >> userCode;

		calculateConversion(userCode, userValue);
 	}  

	// Calculate userValue for different userCodes
 	if ((userCode == 0) || (userCode == 1))                 
 	{
		cout << "Enter the amount in Celsius: ";
 	   
		cin >> userValue;

		originalValue = userValue;

		calculateConversion(userCode, userValue);
 	  
		while (userCode == 6)
 	    {
 	    	cout << "Wrong input, try again: ";

 	    	cin >> userValue;
 	 
 	    	originalValue = userValue;
 	    }
 	   
		if (userCode == 0)
 	    {
 	    	cout << setprecision(3) << fixed << originalValue  <<  " Celsius is " << setprecision(3) << fixed << userValue << " Fahrenheit." << endl; 
 	    }
 	   	else
 	    {
 	    	cout << setprecision(3) << fixed << originalValue << setprecision(3) <<  " Celsius is " << setprecision(3) << fixed << userValue << " Kelvin." << endl;
 	    }
	}
 	  
	if ((userCode == 2) || (userCode == 3))
	{
 		cout << "Enter the amount in Fahrenheit: ";

		cin >> userValue;

		originalValue = userValue;

		calculateConversion(userCode, userValue);

		while (userCode == 6) 
 	    {
 	    	cout << "Wrong input, try again: ";

			cin >> userValue;

			originalValue = userValue;
		}
 	    
 	    if (userCode == 2)
 	    {
 	    	cout << setprecision(3) << fixed << originalValue << " Fahrenheit is " << setprecision(3) << fixed << userValue << " Celsius." << endl;
 	    }
 	    else
 	   	{
 	    	cout  << setprecision(3) << fixed << originalValue << " Fahrenheit is " << setprecision(3) << fixed << userValue << " Kelvin." << endl;
 	    }
	}
 	  
 	
 	if ((userCode == 4) || (userCode == 5))
 	{
 		cout << "Enter the amount in Kelvin: ";

		cin >> userValue;

		originalValue = userValue;
 	 
		calculateConversion(userCode, userValue);
 	
		while (userCode == 6)
 	    {
 	    	cout << "Wrong input, try again: ";

			cin >> userValue;

 	    	originalValue = userValue;
 	    }
 	   
 	    if (userCode == 4)
 	    {
 	    	cout  << setprecision(3) << fixed << originalValue << " Kelvin is " << setprecision(3) << fixed << userValue << " Celsius." << endl;
 	    }
 	   	else
 	    {
 	   	cout  << setprecision(3) << fixed << originalValue << " Kelvin is " << setprecision(3) << fixed << userValue << " Fahrenheit." << endl;
 	    }
	}
 	
 	
	return 0;
}
