#include <iostream>

using namespace std;

int main()
{
	int a; //input 1 - will be altered
	int b; //input 2 - will be altered
	int a1; //input 1 - will not be altered
	int b1; //input 2 - will not be altered
	unsigned int ans; //hamming distance

	cout<<"Enter two positive integers: \n";
	cin>>a;
	cin>>b;
	a1 = a;
	b1 = b;

	}
	while(a>0 || b>0)
	{
		if ((a%16)!=(b%16))
			ans++;
	a = (a-(a%16))/16;
	b = (b-(b%16))/16;
	}
		
		
	cout<<"Hamming distance between "<<a1<<" and "<<b1<<" when numbers are in hex format is: "<<ans<<"\n";
	return 0;

}