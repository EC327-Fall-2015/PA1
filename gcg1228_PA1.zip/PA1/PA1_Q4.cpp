#include <iostream>
using namespace std;

int main(){
	char input; //Original character
	int convert; //Offset
	int ascii; //ascii value of both input and output

	cout<<"Enter Character: ";
	cin>>input;
	cout<<"Offset (enter 0 to convert case): ";
	cin>>convert;
	ascii = int(input);
	if (ascii>=65 && ascii<=90 && convert == 0) //If capital and c=0 turn lower case
		ascii = ascii + 32;
	else if (ascii>= 97 && ascii<=122 && convert == 0) //If lower case and c=0 turn capital
		ascii = ascii - 32;
	else
		ascii = ascii + convert;
	if (ascii>127){
		cout<<"Error. Out of range.\n";
		return 0;
	}
	input = char(ascii);
	cout<<"New Character: "<<input<<"\n";
return 0;
}