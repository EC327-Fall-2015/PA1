#ifndef KtoF_H
#define KtoF_H
double KtoF(double K);
#endif