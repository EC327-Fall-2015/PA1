#include <iostream>
#include <iomanip>
#include "CtoF.H"
#include "CtoK.H"
#include "FtoC.H"
#include "FtoK.H"
#include "KtoC.H"
#include "KtoF.H"

using namespace std;

int main(){
	int num;
	double before;
	double after;
	cout<<"Celsius to Fahrenheit (enter 0)\n";
	cout<<"Celsius to Kelvin (enter 1)\n";
	cout<<"Fahrenheit to Celsius (enter 2)\n";
	cout<<"Fahrenheit to Kelvin (enter 3)\n";
	cout<<"Kelvin to Celsius (enter 4)\n";
	cout<<"Kelvin to Fahrenheit (enter 5)\n";
	cout<<"Conversion type: ";
	cin>>num;
	while(0>num || num>5)
	{	
		cout<<"Wrong input, try again: ";
		cin>>num;
		cout<<"\n";
	}
	if (num==0)
	{	cout<<"Enter the amount in Celcius: ";
		cin>>before;
		after = CtoF(before);
		cout<<before<<" Celcius is "<<fixed<<setprecision(3)<<after<<" Fahrenheit.\n";
		return 0;}
	else if (num==1)
	{	cout<<"Enter the amount in Celcius: ";
		cin>>before;
		after = CtoK(before);
		cout<<before<<" Celcius is "<<fixed<<setprecision(3)<<after<<" Kelvin.\n";
		return 0;}
	else if (num==2)
	{	cout<<"Enter the amount in Fahrenheit: ";
		cin>>before;
		after = FtoC(before);
		cout<<before<<" Fahrenheit is "<<fixed<<setprecision(3)<<after<<" Celcius.\n";
		return 0;}
	else if (num==3)
	{	cout<<"Enter the amount in Fahrenheit: ";
		cin>>before;
		after = FtoK(before);
		cout<<before<<" Fahrenheit is "<<fixed<<setprecision(3)<<after<<" Kelvin.\n";
		return 0;}
	else if (num==4)
	{	cout<<"Enter the amount in Kelvin: ";
		cin>>before;
		after = KtoC(before);
		cout<<before<<" Kelvin is "<<fixed<<setprecision(3)<<after<<" Celcius.\n";
		return 0;}
	else if (num==5)
	{	cout<<"Enter the amount in Kelvin: ";
		cin>>before;
		after = KtoF(before);
		cout<<before<<" Kelvin is "<<fixed<<setprecision(3)<<after<<" Fahrenheit.\n";
		return 0;}
}