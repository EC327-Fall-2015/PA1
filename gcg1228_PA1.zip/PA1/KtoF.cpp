double KtoF(double K)
{double F;
F = (K+459.67)/1.8;
return F;}