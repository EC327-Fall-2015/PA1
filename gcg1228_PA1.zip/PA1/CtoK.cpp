double CtoK(double C)
{double K;
K = C+273.15;
return K;}