#ifndef FtoC_H
#define FtoC_H
double FtoC(double F);
#endif