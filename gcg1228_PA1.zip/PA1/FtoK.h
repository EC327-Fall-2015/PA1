#ifndef FtoK_H
#define FtoK_H
double FtoK(double F);
#endif