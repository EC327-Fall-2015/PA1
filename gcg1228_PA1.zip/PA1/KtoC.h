#ifndef KtoC_H
#define KtoC_H
double KtoC(double K);
#endif