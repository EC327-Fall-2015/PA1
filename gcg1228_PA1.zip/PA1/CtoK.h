#ifndef CtoK_H
#define CtoK_H
double CtoK(double C);
#endif