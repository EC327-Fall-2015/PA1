#include <iostream>
#include "math.h"
using namespace std;

int main(){
	double a; //side 1
	double b; //side 2
	double c; //side 3
	double a1; //side 1-not altered
	double b1; //side 2-not altered
	double c1; //side 3-not altered
	double hyp; //save longest side
	double s; //s-parameter
	double area;
	double perimeter;

	cout<<"Enter the dimesnions of the triangle: \n";
	cout<<"Side-1: ";
	cin>>a;
	cout<<"Side-2: ";
	cin>>b;
	cout<<"Side-3: ";
	cin>>c;	
	a1 = a;
	b1 = b;
	c1 = c;

	if(a>=b && a>=c) //max function
	{
		hyp = a;
		a = b;
		b = c;
	}
	else if(b>=a && b>=c)
	{
		hyp = b;
		a = a;
		b = c;
	}
	else if(c>=a && c>=b)
	{
		hyp = c;
		a = a;
		b = b;
	}				//end max function
	if ((a+b)<hyp){ //if eligable triangle
		cout<<"Dimesnions "<<a1<<", "<<b1<<", "<<c1<<" do not form a triangle. \n";
	return 0;
	}
	else{
		perimeter = a1+b1+c1;
		s = perimeter/2;
		area = sqrt(s*(s-a1)*(s-b1)*(s-c1));
		cout<<"This triangle's area is "<<area<<" square-units and its perimeter is "<<perimeter<<" units.\n";
		return 0;}

}