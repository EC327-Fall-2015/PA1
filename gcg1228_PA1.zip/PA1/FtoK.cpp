double FtoK(double F)
{double K;
K = (F-32)/1.8+273.15;
return K;}