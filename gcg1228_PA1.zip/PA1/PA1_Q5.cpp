#include <iostream>
using namespace std;

int main(){
	int answer = rand();
	int guess1;
	int guess2;
	int distance1;
	int distance2;


	cout<<"Enter your first guess: ";
	cin>>guess1;
	do{
		if (guess1 == answer)
	{
		cout<<"Correct! The number was "<<answer<<"\n";
		return 0;
	}
		cout<<"Enter your next guess: ";
		cin>>guess2;
		distance1 = (answer - guess1);
		distance2 = (answer - guess2);
		if (distance1<0) //make distances positive
			distance1 = distance1 * -1;
		if (distance2<0)
			distance2 = distance2 * -1;
		if (guess2 == answer){
			cout<<"Correct! The number was "<<answer<<"\n";
		return 0;
		}
		if (distance2>distance1)
			cout<<"Colder\n";
		else if (distance2<distance1)
			cout<<"Warmer\n";
		else
			cout<<"No change\n";
		cout<<"Enter your next guess: ";
		cin>>guess1;
		distance1 = (answer - guess1);
		distance2 = (answer - guess2);
		if (distance1<0) //make distances positive
			distance1 = distance1 * -1;
		if (distance2<0)
			distance2 = distance2 * -1;
		if (guess1 == answer){
			cout<<"Correct! The number was "<<answer<<"\n";
		return 0;
		}
		if (distance1>distance2)
			cout<<"Colder\n";
		else if (distance1<distance2)
			cout<<"Warmer\n";
		else
			cout<<"No change\n";} while (guess1 != answer && guess2 != answer);
}



