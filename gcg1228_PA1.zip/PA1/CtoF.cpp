double CtoF(double C)
{double F;
F = (C*1.8)+32;
return F;}