double FtoC(double F)
{double C;
C = (F-32)/1.8;
return C;}