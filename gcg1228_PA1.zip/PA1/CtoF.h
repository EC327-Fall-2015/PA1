#ifndef CtoF_H
#define CtoF_H
double CtoF(double C);
#endif