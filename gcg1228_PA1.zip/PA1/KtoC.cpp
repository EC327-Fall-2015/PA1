double KtoC(double K)
{double C;
C = K-273.15;
return C;}